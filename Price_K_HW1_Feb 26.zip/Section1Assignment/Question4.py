# List
a = [5, 10, 15, 20, 25]

# Find First
first = a[0]
print("First in List: " + str(first))

# Find Last
last = a[-1]
print("Last in List: " + str(last))